

import PPModule.*;

public class PingObjectImpl extends _PingObjectImplBase {

  public PingObjectImpl(String name) {
    super(name);
  }

  protected int _maxPings = 1;

  public void maxPings(int maxPings) {
    _maxPings = maxPings;
  }

  public int maxPings() {
    return _maxPings;
  }

  public int ping(PongObject po, int count) {
    System.out.println("ping:" + System.currentTimeMillis());
    if(count < maxPings())
      return po.pong(this,count+1);
    else
      return count;
  }

}
