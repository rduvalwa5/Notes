

import PPModule.*;

public class PongObjectImpl extends _PongObjectImplBase {

  public PongObjectImpl(String name) {
    super(name);
  }

  public PongObjectImpl() { }

  public int pong(PingObject po, int count) {
    System.out.println("pong:" + System.currentTimeMillis());
    return po.ping(this,count+1);
  }


}
