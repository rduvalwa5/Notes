
import PPModule.*;

public class PingServer {

  public static void main(String[] args) {

    // Initialize the ORB.

    // Initialize the BOA.

    // Create a PingObject instance

    // Set the maximum number of pings

    // Export the newly created object.

    // Print out a message that the object is ready

    // Wait for incoming requests
  }

}

