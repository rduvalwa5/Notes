
import PPModule.*;

public class PongServer {

  public static void main(String[] args) {

    // Initialize the ORB.

    // Locate a PongObject instance

    // Initialize the BOA.

    // Create a PongObject instance

    // Export the newly created object.

    // Print out a message that the object is ready
    System.out.println(pongObject + " is ready.");

    // ping the pingObject
    
  }

}

