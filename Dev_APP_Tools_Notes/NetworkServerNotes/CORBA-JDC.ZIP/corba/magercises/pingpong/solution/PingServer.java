
import PPModule.*;

public class PingServer {

  public static void main(String[] args) {

    // Initialize the ORB.
    org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

    // Initialize the BOA.
    org.omg.CORBA.BOA boa = orb.BOA_init();

    // Create a PingObject instance
    PingObject pingObject = new PingObjectImpl("pingObject");

    // Set the maximum number of pings
    pingObject.maxPings(10);

    // Export the newly created object.
    boa.obj_is_ready(pingObject);

    // Print out a message that the object is ready
    System.out.println(pingObject + " is ready.");

    // Wait for incoming requests
    boa.impl_is_ready();
  }

}

