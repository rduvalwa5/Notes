
import StockObjects.*;

public class StockImpl extends StockObjects._StockImplBase {

    private Quote _quote=null;
    private String _description=null;

    public StockImpl(String name,String description) {
        super();
        _description = description;
    }

    public Quote get_quote() throws Unknown {
        if (_quote==null) throw new Unknown();
        return _quote;
    }
    public void set_quote(Quote quote) {
        _quote = quote;
    }
		

    public String description() {
        return _description;
    }

}
