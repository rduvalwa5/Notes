
import java.io.*;
import org.omg.CORBA.*;
import StockObjects.*;

public class StockClient {
    public static void main(String args[]) {
        if (args.length!=1) {
            System.err.println("Required argument: stock ior file");
            return;
        }
        try{
	        // create and initialize the ORB
	        ORB orb = ORB.init(args, null);

	        // Read in a stringified reference to a stock object
            // This assumes that the server created it
	        BufferedReader in = new BufferedReader(new FileReader(args[0]));
	        String ior = in.readLine();
	        in.close();

	        // "destringify" the object
	        org.omg.CORBA.Object obj = orb.string_to_object(ior);
            // narrow it to a stock object
            Stock theStock = StockHelper.narrow(obj);

	        // call the stock object for it's description and current price
            Quote currentQuote = theStock.get_quote();
            System.out.print(theStock.description());
            System.out.println(" is currently selling at "+currentQuote.price);
            System.out.println("Volume is "+currentQuote.volume);
	    } catch (Exception e) {
	        e.printStackTrace(System.out);
	    }
    }
}
