
import StockObjects.*;

public class StockImpl extends StockObjects._StockImplBase {

    private Quote _quote=null;
    private String _description=null;

    public StockImpl(String name,String description) {
        super();
        _description = description;
    }

    public Quote get_quote() throws Unknown {
        if (_quote==null) throw new Unknown();
        return _quote;
    }
// *** put your method implementing the IDL operation
//     for setting the quote here


    public String description() {
        return _description;
    }

}
