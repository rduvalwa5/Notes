
import java.util.Vector;
import MessageModule.*;



public class MessageBoxImpl extends _MessageBoxImplBase {



}
