
import MessageModule.*;

public class MBClient {

    public static void main(String[] args) {

	// The first command-line argument says where to do it
	String server = args[0];
	// The second command-line argument says what to do
	String action = args[1];
	// The third command-line argument says how to do it
	String param = (args.length > 2) ? args[2] : null;
	    
	// Initialize the ORB.
	org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args, null);

	// Locate the MessageBox instance
	MessageBox mb = MessageBoxHelper.bind(orb, server);

	if (action.equals("reply"))
	{
	    // set the reply
	}

	else if (action.equals("leave"))
	{
	    // leave a message
	}
    
	else if (action.equals("get"))
	{
	    // get messages
	}
    } 
}
