
import java.util.Vector;
import MessageModule.*;



public class MessageBoxImpl extends _MessageBoxImplBase {


    public MessageBoxImpl(String name, int max) {
	super(name);
	_max = max;
	_messages = new Vector(max);
	_reply = "Thank you for leaving a message.";
    }

    protected String _reply;
    protected int _max;
    protected Vector _messages;

    public void reply(java.lang.String reply) {
	_reply = reply;
	System.out.println("Set Reply: " + reply);
    }

    public java.lang.String reply() {
	return _reply;
    }

    public java.lang.String leaveMessage(java.lang.String msg)
	throws MessageModule.MessageBoxPackage.boxFull {

	if (_messages.size() > _max)
	    throw new MessageModule.MessageBoxPackage.boxFull();

	_messages.addElement(msg);
	System.out.println("Added Message: " + msg);
	return reply();
    }
    
    public java.lang.String[] getMessages() {
	System.out.println("Getting messages");
	String[] messages = new String[_messages.size()];
	_messages.copyInto(messages);
	_messages = new Vector(_max);
	return messages;
    }



}
