
import MessageModule.*;

public class MBServer {

  public static void main(String[] args) {

    // Initialize the ORB.
    org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

    // Initialize the BOA.
    org.omg.CORBA.BOA boa = ((com.visigenic.vbroker.orb.ORB)orb).BOA_init();

    // Create the a SeqTestImpl instance
    String name = "myMessages";
    if (args.length > 0)
	name = args[0];
    MessageBox mb = new MessageBoxImpl(name, 5);

    // Export the newly created object.
    boa.obj_is_ready(mb);
    System.out.println(mb + " is ready.");

    // Wait for incoming requests
    boa.impl_is_ready();
  }

}

