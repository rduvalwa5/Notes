
import MessageModule.*;

public class MBClient {

    public static void main(String[] args) {

	// The first command-line argument says where to do it
	String server = args[0];
	// The second command-line argument says what to do
	String action = args[1];
	// The third command-line argument says how to do it
	String param = (args.length > 2) ? args[2] : null;
	    
	// Initialize the ORB.
	org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args, null);

	// Locate the MessageBox instance
	MessageBox mb = MessageBoxHelper.bind(orb, server);

	if (action.equals("reply"))
	{
	    // set the reply
	    mb.reply(param);
	}

	else if (action.equals("leave"))
	{
	    // leave a message
	    try {
		System.out.println(mb.leaveMessage(param));
		System.out.println("Left message " + param);
	    }
	    catch (MessageModule.MessageBoxPackage.boxFull e) {
		System.out.println("Box full; message not left.");
	    }
	}
    
	else if (action.equals("get"))
	{
	    // get messages
	    String[] messages = mb.getMessages();
	    System.out.println("Here are your messages:");
	    for(int i = 0; i < messages.length; i++)
		System.out.println("  " + messages[i]);
	}
    } 
}
