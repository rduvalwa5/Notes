import StockObjects.*;

public class StockFactoryImpl extends StockObjects._StockFactoryImplBase {

    public StockFactoryImpl() {
        super();
    }
	
    public Stock create_stock(String symbol,String description){
        StockImpl newStock = new StockImpl(symbol, description);
        return newStock;
    }

}
