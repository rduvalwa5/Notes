import java.io.*;
import StockObjects.*;

// This is a main function for a server.

public class DynamicStockServer {
    public static void main(String[] args) {
        if (args.length!=1) {
            System.err.println("Required argument: stock factory ior file");
            return;
        }
        try {
            // Initialize the ORB.
            org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);

            // Create a stock factory object.
            StockFactoryImpl stockFactory = new StockFactoryImpl();
			orb.connect(stockFactory);
			
            // print stringified object reference
            System.out.println( "Created stock factory\n" + orb.object_to_string(stockFactory) );

            // write stringified object reference to disk
            PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(args[0])));
            out.println( orb.object_to_string(stockFactory) );
            out.close();
						
			// wait for invocations from clients
			java.lang.Object sync = new java.lang.Object();
			synchronized (sync) {
				sync.wait();
            }

        } catch (Exception e) {
	        System.err.println("Stock server error: " + e);
	        e.printStackTrace(System.out);
	    }
    }
}




