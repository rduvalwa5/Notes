import StockObjects.*;

public class StockFactoryImpl extends StockObjects._StockFactoryImplBase {

    public StockFactoryImpl() {
        super();
    }
	
// *** put your method implementing the IDL operation
//     for setting the quote here

}
