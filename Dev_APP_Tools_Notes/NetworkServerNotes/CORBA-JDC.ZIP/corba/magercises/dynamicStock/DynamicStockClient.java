import java.io.*;
import org.omg.CORBA.*;
import StockObjects.*;

public class DynamicStockClient {
    public static void main(String args[]) {
        if (args.length!=3) {
            System.err.println("Required arguments: stock-factory-ior-file stock-symbol description");
            return;
        }
        try{
	        // create and initialize the ORB
	        ORB orb = ORB.init(args, null);

	        // Read in a stringified reference to a stock object
	        BufferedReader in = new BufferedReader(new FileReader(args[0]));
	        String ior = in.readLine();
	        in.close();

	        // "destringify" the factory object
	        org.omg.CORBA.Object obj = orb.string_to_object(ior);
            // narrow it to a stock factory
            StockFactory theFactory = StockFactoryHelper.narrow(obj);

	        // create a stock object
            Stock newStock = theFactory.create_stock(args[1],args[2]);

            // report that the stock object has been created
            System.out.println("Created "+args[1]+ " for "+args[2]);

	    } catch (Exception e) {
	        e.printStackTrace(System.err);
	    }
    }
}
